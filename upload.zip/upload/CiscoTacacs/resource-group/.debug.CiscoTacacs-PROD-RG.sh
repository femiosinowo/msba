export BACKEND_SUBSCRIPTION_ID="3f8d8b8f-002e-44a2-bd8c-37ad733fbd23"
export BACKEND_RESOURCE_GROUP_NAME="AZ-Terraform-ETS-Prod-RG"
export BACKEND_STORAGE_ACCOUNT_NAME="azterraformstatefileprod"
export BACKEND_STORAGE_CONTAINER_NAME="ciscotacacs-prod-rg"
export TF_BACKEND_KEY="ciscotacacs-prod-rg-only.tfstate"

export ENVIRONMENT="PROD"
#export TF_WORKSPACE="acr-"$ENVIRONMENT
#rm -rf .terraform
#terraform workspace new acr-$ENVIRONMENT
#terraform workspace select -or-create acr-$ENVIRONMENT

echo '=== AzureRM Backend Config ==='
echo 'Environment: '$ENVIRONMENT
echo 'Subscription ID: '$BACKEND_SUBSCRIPTION_ID
echo 'Resource Group Name: '$BACKEND_RESOURCE_GROUP_NAME
echo 'Storage Account Name: '$BACKEND_STORAGE_ACCOUNT_NAME
echo 'Storage Account Container Name: '$BACKEND_STORAGE_CONTAINER_NAME
echo 'Key: '$TF_BACKEND_KEY

terraform init  \
  -backend-config="subscription_id=$BACKEND_SUBSCRIPTION_ID" \
  -backend-config="resource_group_name=$BACKEND_RESOURCE_GROUP_NAME" \
  -backend-config="storage_account_name=$BACKEND_STORAGE_ACCOUNT_NAME" \
  -backend-config="container_name=$BACKEND_STORAGE_CONTAINER_NAME" \
  -backend-config="key=$TF_BACKEND_KEY"


terraform plan -var-file="../environments/PROD/CiscoTacacs-PROD-RG.tfvars" -out=state-$ENVIRONMENT

#terraform $1 $2 $3

