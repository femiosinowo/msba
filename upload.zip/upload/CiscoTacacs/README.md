main.tf
```
terraform {

  backend "azurerm" { }
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "3.50"
    }
    time = {
      source  = "hashicorp/time"
      version = "0.9.1"
    }
    azapi = {
      source  = "azure/azapi"
      version = "~>1.5"
    }
  }
}


provider "azurerm" {
  tenant_id       = var.TENANT_ID
  subscription_id = var.SUBSCRIPTION_ID
  features {}
}





module "app_service_plan" {
  source                      = "./modules/app_service_plan"
  name                        = var.name
  location                    = var.location
  resource_group_name         = var.resource_group_name
  sku_name                    = var.sku_name
  os_type                     = var.os_type
}


```
Parameters sample
```
SUBSCRIPTION_ID        = "e1c4ce8d-1031-4e80-bab3-56295338b53b"
#TENANT_ID              = "e1c4ce8d-103104e80-bab3-56295338b53b"
name                   = "appserviceplan"
resource_group_name    = "dptest-dev-RG"
os_type                = "Windows"
sku_name               = "B3"
location               = "eastus2"
```
